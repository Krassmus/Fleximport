<?php

interface FleximportChecker {

    public function check($data, $virtualobject, $relevantfields);

}